from odoo import api, fields, models,_


class StockPicking(models.Model):
    _inherit='stock.picking'


    def button_validate(self):
        if self._context.get('skip_full_qty',False)==False:
            message="The below product lot full quantity will moved completely to the destination location\n"
            lines=[]
            lots=[]
            for picking in self:
                for line in picking.move_ids_without_package:
                    q = self.env['stock.quant'].sudo().search([
                        ('product_id', '=', line.product_id.id),
                        ('quantity', '>=', line.quantity_done),
                        ('location_id', '=', line.location_id.id),
                        ('lot_id', 'not in', lots),
                    ], limit=1)
                    if q:
                        if line.product_id.move_lot_full_qty and line.location_dest_id.move_lot_full_qty and line.quantity_done!=q:
                            lots.append(q.lot_id.id)
                            lines.append((0,0,{
                                'product_id':line.product_id.id,
                                'lot_id':q.lot_id.id,
                                'move_id':line.id,
                                'full_qty':q.quantity,
                                'uom_id':q.product_uom_id.id,
                                'transfer_id':picking.id,
                            }))
            if lines:
                view = self.env.ref('ivs_move_lot_full_qty.full_qty_message')
                return {
                    'name': 'Full Qty Check',
                    'type': 'ir.actions.act_window',
                    'view_type': 'form',
                    'view_mode': 'form',
                    'res_model': 'full.qty.message',
                    'views': [(view.id, 'form')],
                    'view_id': view.id,
                    'target': 'new',
                    'context': {'default_name':message,'default_line_ids':lines},
                }
        res=super().button_validate()
        return res




