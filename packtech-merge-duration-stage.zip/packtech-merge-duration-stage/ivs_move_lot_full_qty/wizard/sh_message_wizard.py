# -*- coding: utf-8 -*-
# Part of Softhealer Technologies.
from odoo import fields, models,api

class FullQtyMessageWizard(models.TransientModel):
    _name = "full.qty.message"
    name = fields.Text(string="Message")
    line_ids= fields.One2many(
        comodel_name='full.qty.message.lines',
        inverse_name='wiz_id',
        string='Products',
        required=False)

    def action_confirm(self):
        for line in self.line_ids:
            for move in line.transfer_id.move_ids_without_package:
                for mline in move.move_line_ids:
                    if move.id==line.move_id.id and line.product_id.id==mline.product_id.id:
                        qty_done = line.uom_id._compute_quantity(line.full_qty, mline.product_uom_id)
                        move.sudo().write({
                              'product_uom_qty':qty_done,
                              'quantity_done':qty_done,
                          })
                        move.move_line_ids.sudo().write({
                            'lot_id':line.lot_id.id,
                        })
            line.transfer_id.sudo().with_context(skip_immediate=True,skip_full_qty=True).button_validate()

class FullQtyMessageWizardLines(models.TransientModel):
    _name = "full.qty.message.lines"
    wiz_id = fields.Many2one( comodel_name='full.qty.message',string='wiz')
    move_id = fields.Many2one( comodel_name='stock.move',string='move',readonly=True)
    lot_id = fields.Many2one( comodel_name='stock.lot',string='Lot')
    transfer_id = fields.Many2one( comodel_name='stock.picking',string='Transfer',readonly=True)
    product_id = fields.Many2one( comodel_name='product.product',string='Product',readonly=True)
    uom_id = fields.Many2one( comodel_name='uom.uom',string='UoM',readonly=True)
    full_qty = fields.Float(string='Full Quantity')

    @api.onchange('lot_id')
    def onchange_lot_id(self):
        q = self.env['stock.quant'].sudo().search([
            ('product_id', '=', self.product_id.id),
            ('location_id', '=', self.move_id.location_id.id),
            ('lot_id', '=', self.lot_id.id),
        ], limit=1)
        if q:
            self.full_qty=q.quantity
        else:
            self.full_qty=0
