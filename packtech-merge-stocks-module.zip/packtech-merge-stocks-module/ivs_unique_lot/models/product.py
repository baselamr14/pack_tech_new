# -*- coding: utf-8 -*-

import logging
from odoo import _, api, fields, models
from odoo.osv import expression

_logger = logging.getLogger(__name__)



class ProductTemplate(models.Model):
    _inherit = 'product.template'
    unique_lot = fields.Boolean(string='Unique Lot For  Components')

class StockQuant(models.Model):
    _inherit = 'stock.quant'

    def get_used_lots(self, product_id,production_id):
        mo=self.env['mrp.production'].browse(production_id)
        lots = []
        for raw in mo.move_raw_ids:
            for line in raw.move_line_ids:
                if line.product_id.id == product_id:
                    lots.append(line.lot_id.id)
        return lots
    def get_used_lots2(self,move_ids):
        moves=self.env['stock.move'].browse(move_ids)
        lots = []
        for move in moves:
            for line in move.move_line_ids:
                lots.append(line.lot_id.id)

        return lots


    def _gather(self, product_id, location_id, lot_id=None, package_id=None, owner_id=None, strict=False):
        lots=[]
        flag=False
        if self._context.get('check_unique_lot') and product_id.unique_lot:
            flag=True
            lots1=self.get_used_lots(product_id.id, self._context.get('mo_id'))
            lots2=self.get_used_lots2(self._context.get('move_ids'))
            lots=lots1+lots2

        removal_strategy = self._get_removal_strategy(product_id, location_id)
        removal_strategy_order = self._get_removal_strategy_order(removal_strategy)

        domain = [('product_id', '=', product_id.id)]
        if not strict:
            if lot_id:
                domain = expression.AND([['|', ('lot_id', '=', lot_id.id), ('lot_id', '=', False)], domain])
            if lots and flag:
                domain = expression.AND([[ ('lot_id', 'not in', lots)], domain])
            if package_id:
                domain = expression.AND([[('package_id', '=', package_id.id)], domain])
            if owner_id:
                domain = expression.AND([[('owner_id', '=', owner_id.id)], domain])
            domain = expression.AND([[('location_id', 'child_of', location_id.id)], domain])
        else:
            domain = expression.AND([['|', ('lot_id', '=', lot_id.id), ('lot_id', '=', False)] if lot_id else [('lot_id', '=', False)], domain])
            domain = expression.AND([[('package_id', '=', package_id and package_id.id or False)], domain])
            domain = expression.AND([[('owner_id', '=', owner_id and owner_id.id or False)], domain])
            domain = expression.AND([[('location_id', '=', location_id.id)], domain])
        return self.search(domain, order=removal_strategy_order).sorted(lambda q: not q.lot_id)
class StockMove(models.Model):
    _inherit = 'stock.move'

    def _action_confirm(self, merge=True, merge_into=False):
        flag=False
        for rec in self:
            if rec.product_id.unique_lot:
                merge = False
                flag = True
                break
        if flag:
            self=self.with_context(check_unique_lot=True,move_ids=self.ids)
        moves = self.action_explode()
        merge_into = merge_into and merge_into.action_explode()
        # we go further with the list of ids potentially changed by action_explode
        return super(StockMove, moves)._action_confirm(merge=merge, merge_into=merge_into)

    #
