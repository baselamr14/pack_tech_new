{
    'name': """Reordring Work Orders""",
    'summary': """Reordring Work Orders""",
    'description': """Reordring Work Orders""",
    'author': 'I Value Solutions',
    'website': 'https://www.ivalue-s.com',
    'email': 'info@ivalue-s.com',
    'version': '16.0.0.1',
    'category': 'Manufacturing',
    'license':'OPL-1',
    'depends': ['base','product', 'mrp'],
    'data': [
        'security/security.xml',
        'views/views.xml',
    ],
    'installable': True,
    'auto_install': False,
}
